import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import Home from './pages/Home';
import Vehicles from './pages/Vehicles';
import Admin from './pages/Admin';

export default function App() {
  const { t, i18n } = useTranslation();
  return (
    <BrowserRouter>
      <header className="p-4 shadow flex justify-between">
        <h1>{t('home_title')}</h1>
        <nav>
          <Link to="/">{t('rent')}</Link> | <Link to="/vehicles">{t('vehicles')}</Link> | <Link to="/admin">{t('admin')}</Link>
        </nav>
        <select value={i18n.language} onChange={(e)=>i18n.changeLanguage(e.target.value)}>
          <option value="en">English</option>
          <option value="rw">Kinyarwanda</option>
          <option value="ko">Korean</option>
          <option value="zh">中文</option>
        </select>
      </header>
      <main className="p-4">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/vehicles" element={<Vehicles />} />
          <Route path="/admin" element={<Admin />} />
        </Routes>
      </main>
    </BrowserRouter>
  );
}
