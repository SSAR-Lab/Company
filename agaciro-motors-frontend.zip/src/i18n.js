import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

const resources = {
  en: { translation: { "home_title": "Agaciro Motors", "rent": "Rent a car", "vehicles": "Vehicles", "admin": "Admin" } },
  rw: { translation: { "home_title": "Agaciro Motors", "rent": "Gutwara imodoka", "vehicles": "Imodoka", "admin": "Umuyobozi" } },
  ko: { translation: { "home_title": "아가시로 모터스", "rent": "차 대여", "vehicles": "차량", "admin": "관리자" } },
  zh: { translation: { "home_title": "阿加西罗汽车", "rent": "租车", "vehicles": "车辆", "admin": "管理员" } }
};

i18n.use(initReactI18next).init({
  resources,
  lng: 'en',
  fallbackLng: 'en',
  interpolation: { escapeValue: false }
});

export default i18n;
