import React from 'react';
export default function Vehicles(){return(<div><h2>Available Vehicles</h2><p>Vehicle listing will be displayed here.</p></div>);}