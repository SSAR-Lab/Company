import React from 'react';
export default function Admin(){return(<div><h2>Admin Dashboard</h2><p>Manage vehicles, reservations, and reports here.</p></div>);}